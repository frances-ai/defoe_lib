GEO_PARSER_PATH = "/tmp/defoe/geoparser"
